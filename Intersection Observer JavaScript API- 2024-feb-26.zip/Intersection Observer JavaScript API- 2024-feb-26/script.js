//1- target element ###
const targetdiv1 = document.querySelector(".box-1");
const targetdiv2 = document.querySelector(".box-2");
const targetdiv3 = document.querySelector(".box-3");

const targetdiv6 = document.querySelector(".box-6");
const targetdiv7 = document.querySelector(".box-7");
const targetdiv8 = document.querySelector(".box-8");

//1- target element  කීපයක් ඇතිවිට බලන විදිහ ###
// const targetdivboxes = document.querySelectorAll(".box");



// 3 option - Options කියන්නේ බලන්න ඕන දේවල් 
const Options = {
threshold:0.5,
rootMargin:"0px 0px 0px 0px",
root:null
};

//2- target element ###
const observer = new IntersectionObserver(function(entries){
  entries.forEach(entry => {
    console.log(entry.target)
    const intersecting = entry.isIntersecting;
    if(intersecting){
      entry.target.classList.add("opacityon");
      entry.target.classList.add("blendin");
      observer.unobserve(entry.target);
    } else {
      entry.target.classList.remove("opacityon");
      entry.target.classList.remove("blendin");
    }
    // entry.target.style.backgroundColor = intersecting ? "blue" : "orange"
  })
},Options);




//2- observe -මෙයාව බලන් ඉන්න  ###
observer.observe(targetdiv1);
observer.observe(targetdiv2);
observer.observe(targetdiv3);

observer.observe(targetdiv6);
observer.observe(targetdiv7);
observer.observe(targetdiv8);

//2- observe -කීපයක් ඇතිවිට බලන විදිහ  ###
// targetdivboxes.forEach(targetdivboxes => {
//   observer.observe(targetdivboxes);
// })